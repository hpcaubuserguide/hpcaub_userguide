#BSUB -J my_mpi_job
#BSUB -q medium_priority
#BSUB -n 32
#BSUB -oo my_mpi_job.o%J
#BSUB -eo my_mpi_job.e%J
#BSUB -R "span[ptile=8]"

module load enzo

mpirun enzo CollapseTestNonCosmological.enzo



